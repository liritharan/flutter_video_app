package com.example.flutter_video_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
